package com.DCB.practice.Controller;

import com.DCB.practice.Service.DepartmentService;
import com.DCB.practice.Service.DepartmentServiceImpl;
import com.DCB.practice.entity.Department;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;

    private final Logger LOGGER= LoggerFactory.getLogger(DepartmentController.class);

    @PostMapping("/departments")
    public Department saveDepartment(@Valid @RequestBody  Department department) // With the help of requestbody annotaion we are converting Json object to java object
    {
       // DepartmentService service = new DepartmentServiceImpl();
        LOGGER.info("Inside save Department of department controller");
        return departmentService.saveDepartment(department);
    }

    @GetMapping("/departments")
    public List <Department> fetchDepartmentList()
    {
        LOGGER.info("Inside get department of department controller");
        return departmentService.fetchDepartmentList();
    }

    @GetMapping("departments/{id}")
    public Department fetchDepartmentById(@PathVariable("id") Long departmentId)
    {
        return departmentService.fetchDepartmentById(departmentId);

    }

    @DeleteMapping("departments/{id}")
    public String deleteDepartmentById(@PathVariable("id") Long departmentId)
    {
         departmentService.deleteDepartmentById(departmentId);
         return "DELETED!";

    }

    @PutMapping("departments/{id}")
    public Department updateDepartment(@PathVariable("id") Long departmentId, @RequestBody Department department)
    {
        return departmentService.updateDepartment(departmentId,department);
    }

    @GetMapping("departments/name/{name}")
    public Department fetchDepartmentByName(@PathVariable("name") String departmentName)
    {
        return departmentService.fetchDepartmentByName(departmentName);

    }
}






