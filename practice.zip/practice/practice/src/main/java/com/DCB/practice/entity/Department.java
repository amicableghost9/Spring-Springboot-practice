package com.DCB.practice.entity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;

@Entity //this is used to create the connection with the database
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Department
{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)  //creating primary key
    private Long departmentId;
    private String departmentAddress;
    @NotBlank(message = "Please add department name")
    private String departmentName;
    private String departmentCode;








  /*  public Department()
    {

    }

    public Department(Long departmentId, String departmentAddress, String departmentName, String departmentCode) {
        this.departmentId = departmentId;
        this.departmentAddress = departmentAddress;
        this.departmentName = departmentName;
        this.departmentCode = departmentCode;
    }



    public Long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }

    public String getDepartmentAddress() {
        return departmentAddress;
    }

    public void setDepartmentAddress(String departmentAddress) {
        this.departmentAddress = departmentAddress;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public String getDepartmentCode() {
        return departmentCode;
    }

    public void setDepartmentCode(String departmentCode) {
        this.departmentCode = departmentCode;
    }

    @Override
    public String toString() {
        return "Department{" +
                "departmentId=" + departmentId +
                ", departmentAddress='" + departmentAddress + '\'' +
                ", departmentName='" + departmentName + '\'' +
                ", departmentCode='" + departmentCode + '\'' +
                '}';
    }*/
}
